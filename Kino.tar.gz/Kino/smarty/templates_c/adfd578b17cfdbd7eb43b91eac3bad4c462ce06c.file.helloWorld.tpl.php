<?php /* Smarty version Smarty-3.1.13, created on 2018-05-30 11:59:40
         compiled from "/var/www/html/iksy05/9/smarty/templates/helloWorld.tpl" */ ?>
<?php /*%%SmartyHeaderCode:702078835b0e760cd35697-98812027%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'adfd578b17cfdbd7eb43b91eac3bad4c462ce06c' => 
    array (
      0 => '/var/www/html/iksy05/9/smarty/templates/helloWorld.tpl',
      1 => 1524038752,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '702078835b0e760cd35697-98812027',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'ausgabe' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5b0e760cd87ea0_04588499',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b0e760cd87ea0_04588499')) {function content_5b0e760cd87ea0_04588499($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hello World</title>
</head>
<body>
    <?php echo $_smarty_tpl->tpl_vars['ausgabe']->value;?>

</body>
</html><?php }} ?>
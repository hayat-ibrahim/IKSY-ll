<?php


require_once ('./includes/startTemplate.inc.php');
require_once ('./klassen/FilmeUebersicht.inc.php');
require_once ('./klassen/Sicherheit.inc.php');

$db = DbFunctions::connectWithDatabase();

$filme = FilmeUebersicht::holeFilme($db);
$smarty->assign('title', 'Startseite');
$smarty->assign('filme', $filme);
$smarty->assign('activePage', 'startseite');  // <-- vor display aufrufen!

$smarty->display('index.tpl');

<?php
session_start();
require_once('./includes/startTemplate.inc.php');
require_once('./klassen/PreisBerechnung.inc.php');
require_once('./klassen/Sicherheit.inc.php');

// Warenkorb aus der Session holen
$warenkorb = $_SESSION['warenkorb'] ?? [];

// Gesamtpreis berechnen
$gesamtpreis = (!empty($warenkorb) && is_array($warenkorb))
? PreisBerechnung::berechneGesamtPreis($warenkorb)
: 0.0;

$gesamtpreisString = number_format($gesamtpreis, 2, ',', '') . ' €';

// Standard-Zuweisungen für Template (vermeidet Warnungen)
$smarty->assign('buchung_gespeichert', false);
$smarty->assign('zahlung', '');
$smarty->assign('bestaetigt', false);
$smarty->assign('agb', false);

// Formular abgeschickt
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $zahlung = $_POST['zahlung'] ?? '';
    $agb = isset($_POST['agb']);
    $nutzerId = $_SESSION['nutzer_id'] ?? null;
    
    if ($agb && $nutzerId && $gesamtpreis > 0) {
        // Buchung speichern
        PreisBerechnung::speichereGesamtBuchung($gesamtpreis, $nutzerId, $zahlung);
        
        // Template-Flags setzen
        $smarty->assign('buchung_gespeichert', true);
        $smarty->assign('zahlung', $zahlung);
    }
    
    // Immer übergeben für Feedback im Template
    $smarty->assign('bestaetigt', true);
    $smarty->assign('agb', $agb);
}

// Preise und Seitendaten übergeben
$smarty->assign('gesamtpreis', $gesamtpreisString);
$smarty->assign('activePage', 'buchung');
$smarty->display('buchung.tpl');

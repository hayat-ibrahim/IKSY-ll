<?php
    //startTemplate.inc.php
    $ROOT_DIR='/var/www/html/iksy05/Kino';
    require_once("$ROOT_DIR/klassen/smarty/libs/Smarty.class.php");
    $smarty=new Smarty();
    $smarty->setTemplateDir("$ROOT_DIR/smarty/templates/");
    $smarty->setCompileDir("$ROOT_DIR/smarty/templates_c/");
    $smarty->setConfigDir("$ROOT_DIR/smarty/configs/");
    $smarty->setCacheDir("$ROOT_DIR/smarty/cache/");
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    
    // Beispiel: Wenn Benutzer eingeloggt ist, setze $isLoggedIn = true, sonst false
    $isLoggedIn = isset($_SESSION['user']); // Je nachdem, wie du Login speicherst
    
    $smarty->assign('isLoggedIn', $isLoggedIn);
    
?>
